package processor.pipeline;

import generic.Instruction;
import processor.Processor;
import generic.Instruction.OperationType;

public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	
	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
	}
	
	public void performMA()
	{
		if(EX_MA_Latch.isMA_enable() == true){

			Instruction currentInstruction = EX_MA_Latch.getInstruction();

			int ALU_output = EX_MA_Latch.getAluResult();
			int alu = ALU_output;

			OperationType currentOP= currentInstruction.getOperationType();

			System.out.println("\nMA Stage");

			if(currentOP == OperationType.store){

				System.out.println("Operation = " + currentOP.name());
				int stWord = containingProcessor.getRegisterFile().getValue(currentInstruction.getSourceOperand1().getValue());

				int word = stWord;
				containingProcessor.getMainMemory().setWord(alu, word);

				System.out.println("Storing = " + word + " into Memory location = " + alu);
			}

			else if(currentOP == OperationType.load){

				System.out.println("Operation = " + currentOP.name());
				int ldWord = containingProcessor.getMainMemory().getWord(ALU_output);

				int ld = ldWord;
				MA_RW_Latch.setLdResult(ld);

				System.out.println("ld Result = " + ld);

			}

			MA_RW_Latch.setAluResult(alu);
			MA_RW_Latch.setInstruction(currentInstruction);
			EX_MA_Latch.setMA_enable(false);
			MA_RW_Latch.setRW_enable(true);
		}
	}
}