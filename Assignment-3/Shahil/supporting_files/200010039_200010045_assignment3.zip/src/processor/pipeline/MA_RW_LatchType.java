package processor.pipeline;
import generic.Instruction;

public class MA_RW_LatchType {
	
	boolean RW_enable;
	Instruction instruction;
	int alu_output;
	int load_output;


	public MA_RW_LatchType(){
		RW_enable = false;
	}

	public void setInstruction(Instruction instruction){
		this.instruction = instruction;
	}

	public void setRW_enable(boolean rW_enable) {
		RW_enable = rW_enable;
	}

	public void setAluResult(int ALUResult){
		this.alu_output = ALUResult;
	}

	public void setLdResult(int LDResult){
		this.load_output = LDResult;
	}


	public Instruction getInstruction() {
		return instruction;
	}

	public boolean isRW_enable() {
		return RW_enable;
	}

	public int getAluResult(){
		return this.alu_output;
	}

	public int getLdResult(){
		return this.load_output;
	}

}
