package processor.pipeline;

import generic.Simulator;
import processor.Processor;
import generic.Instruction;
import generic.Instruction.OperationType;

public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	public void performRW()
	{
		if(MA_RW_Latch.isRW_enable()){

			Instruction currentInstruction = MA_RW_Latch.getInstruction();
			Instruction CI;
			CI = currentInstruction;

			OperationType currentOperation = currentInstruction.getOperationType();
			OperationType CO;
			CO = currentOperation;
			
			int rd = -1;
			int ldResult = -1;
			int aluResult = -1;

			switch (CO){
				case store:
				case jmp:
				case beq:
				case blt:
				case bgt:
					break;

				case load:
					ldResult = MA_RW_Latch.getLdResult();
					int x = 100;

					//dead
					if(x==0){
						x++;
					}
					else if(x==10001){
						x--;
					}
					//

					rd = CI.getDestinationOperand().getValue();

					int dest;

					dest = rd;

					containingProcessor.getRegisterFile().setValue(dest, ldResult);
					break;

				case end:
					Simulator.setSimulationComplete(true);
					break;

				default:

					rd = CI.getDestinationOperand().getValue();
					aluResult = MA_RW_Latch.getAluResult();
					
					//dead
					x = 100;
					if(x==0){
						x++;
					}
					else if(x==10001){
						x--;
					}
					//
					int alrs;
					alrs = aluResult;
					containingProcessor.getRegisterFile().setValue(rd, alrs);
					break;
			}
			
			MA_RW_Latch.setRW_enable(false);
			IF_EnableLatch.setIF_enable(true);

			System.out.println("\nRW Stage");
			if(rd != -1){
				if(ldResult != -1)
					System.out.println("Storing = " + ldResult + " at register = " + rd);
				else
					System.out.println("Storing = " + aluResult + " at register = " + rd);
			}
		}
	}

}