Open and Execute Ass0.java
Then Output.txt will be created automatically
To generate plot, execute plot.py
Graph will be generated.
