public class border {
    int [][] border;
    
    public border(){
        border = new int[3][3];
    }
    public void main(String args[])
    {
        // return bord;
    }
}
