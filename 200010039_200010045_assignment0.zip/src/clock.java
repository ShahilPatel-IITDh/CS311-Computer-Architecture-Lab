public class clock {
    int t;

    public void main(String args[])
    {
        // int t;
        // t+=10;
    }
}
